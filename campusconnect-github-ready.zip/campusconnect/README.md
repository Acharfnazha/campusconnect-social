# CampusConnect (Mini Social)

This is an Instagram‑style mini social network built with **Flask + SQLite**.

## What’s inside

- Modern UI (glass cards, dark mode toggle, mobile bottom navigation)
- Posts (text + image), likes (HTMX), comments
- Stories (image/video) + views + replies
- Explore grid
- Profile page + settings page
- In‑app notifications (likes, comments, follows, messages, story replies, calls)
- Calls (lightweight call requests + call log)
- Email code verification (6‑digit OTP) for account verification + optional 2FA
- Basic security hardening: CSRF, secure cookies, rate limiting on auth POSTs

## Quick start

### 1) Create a virtual environment

```bash
python -m venv .venv
source .venv/bin/activate   # macOS/Linux
# .venv\Scripts\activate    # Windows PowerShell
```

### 2) Install dependencies

```bash
pip install -r requirements.txt
```

### 3) Reset the database (recommended on first run)

```bash
python reset_db.py
```

### 4) Run the server

```bash
python run.py
```

Open: http://127.0.0.1:5000

## If you see “Port 5000 is in use”

Run on a different port:

```bash
python run.py --port 5001
```

Or set an env var:

```bash
PORT=5001 python run.py
```

## Email verification (OTP)

By default, if email is not configured, the app will **print the verification code in the console logs**.

To send real emails, set these environment variables before running:

```bash
export MAIL_SERVER="smtp.gmail.com"
export MAIL_PORT="587"
export MAIL_USE_TLS="1"
export MAIL_USERNAME="your_email@gmail.com"
export MAIL_PASSWORD="your_app_password"
export MAIL_DEFAULT_SENDER="CampusConnect <your_email@gmail.com>"
```

Then run normally:

```bash
python run.py
```

## 2FA (email code on login)

Go to **Settings → Security** and enable **“Require a 6‑digit email code on login”**.

## Notes

- Uploads are stored inside `app/static/`.
- Database is stored in `instance/database.db`.
