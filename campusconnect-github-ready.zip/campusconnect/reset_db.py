import os

from app import create_app, db


def main():
    app = create_app()
    with app.app_context():
        db_path = os.path.join(app.instance_path, "database.db")
        if os.path.exists(db_path):
            os.remove(db_path)
        db.create_all()
    print(f"✅ Database reset: {db_path}")


if __name__ == "__main__":
    main()
