import os
import argparse

from app import create_app, db
from app.models import User

app = create_app()

print("MAIL_SERVER =", app.config.get("MAIL_SERVER"))
print("MAIL_USERNAME =", app.config.get("MAIL_USERNAME"))

with app.app_context():
    db.create_all()

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description="CampusConnect dev server")
    parser.add_argument("--port", type=int, default=int(os.environ.get("PORT", "5000")))
    parser.add_argument("--host", type=str, default=os.environ.get("HOST", "127.0.0.1"))
    args = parser.parse_args()
    app.run(debug=True, host=args.host, port=args.port)
