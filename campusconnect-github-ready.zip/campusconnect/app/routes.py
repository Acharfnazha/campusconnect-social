# app/routes.py
from datetime import datetime
import os

from flask import (
    Blueprint, render_template, request, redirect, url_for, flash, render_template_string, jsonify
)
from flask_login import login_required, current_user
from werkzeug.utils import secure_filename
from sqlalchemy import or_, and_, func

from app import db, limiter
from app.moderation import clean_text
from app.models import (
    User, Post, Like, Comment, ProfileView, Message,
    UserSettings, Story, StoryView, StoryReply, Report, Block,
    Notification, CallLog
)

main = Blueprint('main', __name__)


# ---------- tiny helpers ----------
def _is_blocking(a: User, b: User) -> bool:
    """Graceful fallback if the model methods don't exist yet."""
    if hasattr(a, "is_blocking"):
        return a.is_blocking(b)
    return Block.query.filter_by(blocker_id=a.id, blocked_id=b.id).first() is not None


def _is_blocked_by(a: User, b: User) -> bool:
    if hasattr(a, "is_blocked_by"):
        return a.is_blocked_by(b)
    return Block.query.filter_by(blocker_id=b.id, blocked_id=a.id).first() is not None


# ---------- HTMX like/unlike fragment ----------
# Returns a small button that toggles like state.
# We render this with render_template_string(...) in like/unlike routes.
LIKE_FRAGMENT = """
<form
  hx-post="{{ url_for('main.unlike', post_id=post.id) if liked else url_for('main.like', post_id=post.id) }}"
  hx-swap="outerHTML">
  <input type="hidden" name="csrf_token" value="{{ csrf_token() }}">
  <button type="submit" class="btn btn-sm {{ 'btn-danger' if liked else 'btn-outline-danger' }}">
    ❤️ {{ post.likes|length }}
  </button>
</form>
"""


def _notify(user_id: int, actor_id: int, ntype: str, payload: dict | None = None) -> None:
    """Create an in-app notification (best-effort)."""
    try:
        db.session.add(Notification(user_id=user_id, actor_id=actor_id, type=ntype, payload=payload or {}))
        db.session.commit()
    except Exception:
        db.session.rollback()


# =========================================================
# HOME: Feed (Stories bar + Pagination)
# =========================================================
@main.route("/")
@login_required
def home():
    page = request.args.get("page", 1, type=int)
    per_page = 10

    # feed: followed + me
    followed_ids = [u.id for u in current_user.followed.all()] + [current_user.id]
    posts_q = (
        Post.query
        .filter(Post.user_id.in_(followed_ids))
        .order_by(Post.timestamp.desc())
    )
    pagination = posts_q.paginate(page=page, per_page=per_page, error_out=False)
    posts = pagination.items

    # likes for current user
    liked_post_ids = [like.post_id for like in current_user.likes]

    # stories bar (active, not expired)
    now = datetime.utcnow()
    active_stories = (
        db.session.query(Story)
        .join(User, Story.user_id == User.id)
        .filter(Story.expires_at > now)
        .order_by(Story.created_at.desc())
        .all()
    )

    # group by user, compute unseen flag and latest timestamp
    stories_by_user = {}
    for s in active_stories:
        stories_by_user.setdefault(s.user_id, {"user": s.user, "stories": []})
        stories_by_user[s.user_id]["stories"].append(s)

    story_users = []
    for _, bundle in stories_by_user.items():
        user = bundle["user"]
        stories = bundle["stories"]
        story_ids = [st.id for st in stories]

        seen_ids = {
            sid for (sid,) in db.session.query(StoryView.story_id)
            .filter(StoryView.story_id.in_(story_ids),
                    StoryView.viewer_id == current_user.id)
            .all()
        }
        unseen = len(seen_ids) < len(story_ids)
        latest_ts = max(st.created_at for st in stories)
        story_users.append({"user": user, "latest": latest_ts, "unseen": unseen})

    # sort: unseen first, then most recent
    story_users.sort(key=lambda d: (not d["unseen"], d["latest"]), reverse=True)

    # OPTIONAL: people & events (won't crash if Event doesn't exist)
    people = (
        User.query
        .filter(User.id != current_user.id)
        .order_by(User.username.asc())
        .limit(5).all()
    )
    try:
        # Import here so the file doesn't break if Event isn't defined
        from app.models import Event  # type: ignore
        events = Event.query.order_by(Event.starts_at.asc()).limit(5).all()
    except Exception:
        events = []

    return render_template(
        "home.html",
        posts=posts,
        pagination=pagination,
        liked_post_ids=liked_post_ids,
        story_users=story_users,
        people=people,
        events=events,
    )


# =========================================================
# STORIES: Add + View + Reply
# =========================================================
@main.route("/stories/add", methods=["GET", "POST"])
@limiter.limit("6/minute")
@login_required
def add_story():
    if request.method == "POST":
        media = request.files.get("media")
        caption = (request.form.get("caption") or "").strip()

        if not media or not media.filename:
            flash("Please select an image or video.", "warning")
            return redirect(url_for("main.add_story"))

        os.makedirs("app/static/stories", exist_ok=True)

        filename = secure_filename(media.filename)
        save_path = os.path.join("app/static/stories", filename)
        media.save(save_path)

        ext = filename.rsplit(".", 1)[-1].lower()
        media_type = "video" if ext in ("mp4", "webm", "mov", "m4v") else "image"

        story = Story(
            user_id=current_user.id,
            media_path=f"stories/{filename}",
            media_type=media_type,
            caption=caption,
        )
        db.session.add(story)
        db.session.commit()
        flash("Story added.", "success")
        return redirect(url_for("main.home"))

    return render_template("add_story.html")


@main.route("/stories/<username>")
@login_required
def view_stories(username):
    user = User.query.filter_by(username=username).first_or_404()
    now = datetime.utcnow()

    stories = (
        Story.query
        .filter(Story.user_id == user.id, Story.expires_at > now)
        .order_by(Story.created_at.asc())
        .all()
    )
    if not stories:
        flash("No active stories.", "info")
        return redirect(url_for("main.home"))

    # mark views
    for s in stories:
        if not StoryView.query.filter_by(story_id=s.id, viewer_id=current_user.id).first():
            db.session.add(StoryView(story_id=s.id, viewer_id=current_user.id))
    db.session.commit()

    # prev/next owners with active stories
    user_latest = (
        db.session.query(Story.user_id, func.max(Story.created_at))
        .filter(Story.expires_at > now)
        .group_by(Story.user_id)
        .order_by(func.max(Story.created_at).desc())
        .all()
    )
    ordered_ids = [uid for (uid, _) in user_latest]
    idx = ordered_ids.index(user.id) if user.id in ordered_ids else 0

    prev_username = None
    next_username = None
    if idx > 0:
        pu = User.query.get(ordered_ids[idx - 1])
        prev_username = pu.username if pu else None
    if idx < len(ordered_ids) - 1:
        nu = User.query.get(ordered_ids[idx + 1])
        next_username = nu.username if nu else None

    return render_template(
        "stories_view.html",
        owner=user,
        stories=stories,
        prev_username=prev_username,
        next_username=next_username,
    )


@main.route('/stories/<int:story_id>/reply', methods=['POST'])
@login_required
def reply_to_story(story_id):
    story = Story.query.get_or_404(story_id)
    text = (request.form.get('content') or '').strip()
    if not text:
        flash("Reply cannot be empty.", "warning")
        return redirect(url_for('main.view_stories', username=story.user.username))

    # Save reply
    r = StoryReply(story_id=story.id, sender_id=current_user.id, content=text)
    db.session.add(r)

    # Optional: also send a DM to story owner so they see it in Inbox
    if story.user_id != current_user.id:
        dm = Message(
            sender_id=current_user.id,
            recipient_id=story.user_id,
            content=f"(Story reply) {text}",
            timestamp=datetime.utcnow()
        )
        db.session.add(dm)

        _notify(story.user_id, current_user.id, "story_reply", {"story_id": story.id})

    db.session.commit()
    flash("Reply sent.", "success")
    return redirect(url_for('main.view_stories', username=story.user.username))


# =========================================================
# POSTS: Create / Like / Unlike / Comment / Edit / Delete
# =========================================================
@main.route("/post/new")
@login_required
def new_post():
    """Dedicated compose page (mobile-friendly, Instagram-like)."""
    return render_template("new_post.html")


@main.route("/create", methods=["POST"])
@limiter.limit("10/minute")
@login_required
def create_post():
    content = clean_text((request.form.get("content") or "").strip())
    image = request.files.get("image")

    if not content and (not image or not image.filename):
        flash("Post cannot be empty.", "warning")
        return redirect(url_for("main.home"))

    filename = None
    if image and image.filename:
        filename = secure_filename(image.filename)
        image_path = os.path.join("app/static", filename)
        image.save(image_path)
        filename = filename  # stored in DB

    post = Post(content=content, image=filename, user_id=current_user.id)
    db.session.add(post)
    db.session.commit()
    return redirect(url_for("main.home"))


@main.route("/like/<int:post_id>", methods=["POST", "GET"])
@limiter.limit("60/minute")
@login_required
def like(post_id):
    post = Post.query.get_or_404(post_id)

    # block checks
    if _is_blocking(current_user, post.user) or _is_blocked_by(current_user, post.user):
        flash("Action not allowed.", "danger")
        return redirect(request.referrer or url_for("main.home"))

    if not Like.query.filter_by(user_id=current_user.id, post_id=post_id).first():
        db.session.add(Like(user_id=current_user.id, post_id=post_id))
        db.session.commit()
        if post.user_id != current_user.id:
            _notify(post.user_id, current_user.id, "like", {"post_id": post.id})

    # If HTMX request → return partial
    if request.headers.get("HX-Request"):
        return render_template_string(LIKE_FRAGMENT, post=post, liked=True)

    return redirect(request.referrer or url_for("main.home"))


@main.route("/unlike/<int:post_id>", methods=["POST", "GET"])
@limiter.limit("60/minute")
@login_required
def unlike(post_id):
    post = Post.query.get_or_404(post_id)

    lk = Like.query.filter_by(user_id=current_user.id, post_id=post_id).first()
    if lk:
        db.session.delete(lk)
        db.session.commit()

    # If HTMX request → return partial
    if request.headers.get("HX-Request"):
        return render_template_string(LIKE_FRAGMENT, post=post, liked=False)

    return redirect(request.referrer or url_for("main.home"))


@main.route("/comment/<int:post_id>", methods=["POST"])
@limiter.limit("30/minute")
@login_required
def comment(post_id):
    p = Post.query.get_or_404(post_id)
    if _is_blocking(current_user, p.user) or _is_blocked_by(current_user, p.user):
        flash("Action not allowed.", "danger")
        return redirect(request.referrer or url_for("main.home"))

    text = clean_text((request.form.get("comment") or "").strip())
    if text:
        db.session.add(Comment(content=text, user_id=current_user.id, post_id=post_id))
        db.session.commit()
        if p.user_id != current_user.id:
            _notify(p.user_id, current_user.id, "comment", {"post_id": p.id})
    return redirect(request.referrer or url_for("main.home"))


@main.route("/post/<int:post_id>/edit", methods=["GET", "POST"])
@login_required
def edit_post(post_id):
    post = Post.query.get_or_404(post_id)
    if post.user_id != current_user.id:
        return redirect(url_for("main.home"))

    if request.method == "POST":
        post.content = clean_text((request.form.get("content") or "").strip())
        db.session.commit()
        return redirect(url_for("main.home"))

    return render_template("edit_post.html", post=post)


@main.route("/post/<int:post_id>/delete", methods=["POST"])
@login_required
def delete_post(post_id):
    post = Post.query.get_or_404(post_id)
    if post.user_id != current_user.id:
        return redirect(url_for("main.home"))
    db.session.delete(post)
    db.session.commit()
    return redirect(url_for("main.home"))


# =========================================================
# PROFILE + Visitors
# =========================================================
@main.route("/user/<username>")
@login_required
def user_profile(username):
    user = User.query.filter_by(username=username).first_or_404()

    is_following = False
    is_followed_by = False
    if current_user.is_authenticated and current_user.id != user.id:
        try:
            is_following = current_user.is_following(user)
            is_followed_by = user.is_following(current_user)
        except Exception:
            pass

    if current_user.id != user.id:
        db.session.add(ProfileView(viewer_id=current_user.id, viewed_id=user.id))
        db.session.commit()

    liked_post_ids = [like.post_id for like in current_user.likes]

    recent_views = []
    if current_user.id == user.id:
        recent_views = (
            ProfileView.query
            .filter_by(viewed_id=user.id)
            .order_by(ProfileView.timestamp.desc())
            .limit(5)
            .all()
        )
        changed = False
        for v in user.views_received:
            if getattr(v, "seen", False) is False:
                v.seen = True
                changed = True
        if changed:
            db.session.commit()

    return render_template(
        "profile.html",
        user=user,
        liked_post_ids=liked_post_ids,
        recent_views=recent_views,
        is_following=is_following,
        is_followed_by=is_followed_by,
    )


@main.route('/edit_profile', methods=['GET', 'POST'])
@login_required
def edit_profile():
    if current_user.settings is None:
        db.session.add(UserSettings(user=current_user))
        db.session.commit()

    s = current_user.settings

    if request.method == 'POST':
        s.display_name = request.form.get('display_name') or s.display_name
        s.bio = request.form.get('bio') or ''
        s.major = request.form.get('major') or ''
        gyear = request.form.get('graduation_year') or ''
        s.graduation_year = int(gyear) if gyear.isdigit() else None
        s.website = request.form.get('website') or ''
        s.account_type = request.form.get('account_type') or s.account_type

        # Handle profile image
        image = request.files.get('profile_image')
        if image and image.filename:
            os.makedirs('app/static/profile_pics', exist_ok=True)
            filename = secure_filename(image.filename)
            path = os.path.join('app/static/profile_pics', filename)
            image.save(path)
            current_user.profile_image = f'profile_pics/{filename}'

        db.session.commit()
        flash('Profile updated.', 'success')
        return redirect(url_for('main.user_profile', username=current_user.username))

    return render_template('edit_profile.html', settings=s)


# =========================================================
# FOLLOW / UNFOLLOW (with auto DM)
# =========================================================
@main.route("/follow/<username>")
@login_required
def follow(username):
    user = User.query.filter_by(username=username).first_or_404()

    if user == current_user:
        flash("You cannot follow yourself.", "warning")
        return redirect(url_for("main.user_profile", username=username))

    if _is_blocking(current_user, user) or _is_blocked_by(current_user, user):
        flash("Action not allowed.", "danger")
        return redirect(url_for("main.user_profile", username=username))

    current_user.follow(user)
    db.session.commit()

    _notify(user.id, current_user.id, "follow", {"username": current_user.username})

    dm = Message(
        sender_id=current_user.id,
        recipient_id=user.id,
        content=f"Hey {user.username}, I just followed you! Follow back? 😊",
        timestamp=datetime.utcnow(),
    )
    db.session.add(dm)
    db.session.commit()

    flash(f"You are now following {user.username}!", "success")
    return redirect(request.args.get("next") or url_for("main.user_profile", username=username))


@main.route("/unfollow/<username>")
@login_required
def unfollow(username):
    user = User.query.filter_by(username=username).first_or_404()
    if current_user != user:
        current_user.unfollow(user)
        db.session.commit()
    return redirect(url_for("main.user_profile", username=username))


# =========================================================
# MESSAGES (DM) + INBOX
# =========================================================
@main.route("/inbox")
@login_required
def inbox():
    sent = db.session.query(Message.recipient_id).filter(Message.sender_id == current_user.id)
    received = db.session.query(Message.sender_id).filter(Message.recipient_id == current_user.id)
    partner_ids = {row[0] for row in sent.union(received).all()}
    partner_ids.discard(current_user.id)

    threads = []
    if partner_ids:
        partners = User.query.filter(User.id.in_(partner_ids)).all()
        for u in partners:
            last = (
                Message.query
                .filter(or_(
                    and_(Message.sender_id == current_user.id, Message.recipient_id == u.id),
                    and_(Message.sender_id == u.id, Message.recipient_id == current_user.id),
                ))
                .order_by(Message.timestamp.desc())
                .first()
            )
            unread = Message.query.filter_by(
                sender_id=u.id, recipient_id=current_user.id, is_read=False
            ).count()
            threads.append({"user": u, "last_message": last, "unread": unread})

        threads.sort(
            key=lambda t: (t["last_message"].timestamp if t["last_message"] else datetime.min),
            reverse=True,
        )

    return render_template("inbox.html", threads=threads)


@main.route("/messages/<username>", methods=["GET", "POST"])
@limiter.limit("60/minute")
@login_required
def messages(username):
    partner = User.query.filter_by(username=username).first_or_404()

    if _is_blocking(current_user, partner) or _is_blocked_by(current_user, partner):
        flash("Messaging is disabled.", "danger")
        return redirect(url_for("main.inbox"))

    if request.method == "POST":
        text = clean_text((request.form.get("content") or "").strip())
        if text:
            db.session.add(Message(sender_id=current_user.id,
                                   recipient_id=partner.id, content=text))
            db.session.commit()
            _notify(partner.id, current_user.id, "message", {"from": current_user.username})
        return redirect(url_for("main.messages", username=partner.username))

    convo = (
        Message.query
        .filter(or_(
            and_(Message.sender_id == current_user.id, Message.recipient_id == partner.id),
            and_(Message.sender_id == partner.id, Message.recipient_id == current_user.id),
        ))
        .order_by(Message.timestamp.asc())
        .all()
    )

    changed = False
    for m in convo:
        if m.recipient_id == current_user.id and not m.is_read:
            m.is_read = True
            changed = True
    if changed:
        db.session.commit()

    is_following = current_user.is_following(partner)
    has_msg_from_partner = db.session.query(Message.id).filter_by(
        sender_id=partner.id, recipient_id=current_user.id
    ).first() is not None
    show_follow_back_cta = (not is_following) and has_msg_from_partner

    return render_template(
        "messages.html",
        user=partner,
        messages=convo,
        show_follow_back_cta=show_follow_back_cta,
    )


@main.route("/messages/<int:message_id>/edit", methods=["POST"])
@login_required
def edit_message(message_id):
    msg = Message.query.get_or_404(message_id)
    if msg.sender_id != current_user.id:
        return redirect(url_for("main.inbox"))

    new_text = clean_text((request.form.get("content") or "").strip())
    if new_text:
        msg.content = new_text
        db.session.commit()

    partner_id = msg.recipient_id if msg.sender_id == current_user.id else msg.sender_id
    partner = User.query.get_or_404(partner_id)
    return redirect(url_for("main.messages", username=partner.username))


@main.route("/messages/<int:message_id>/delete", methods=["POST"])
@login_required
def delete_message(message_id):
    msg = Message.query.get_or_404(message_id)
    if msg.sender_id != current_user.id:
        return redirect(url_for("main.inbox"))

    partner_id = msg.recipient_id if msg.sender_id == current_user.id else msg.sender_id
    db.session.delete(msg)
    db.session.commit()

    partner = User.query.get_or_404(partner_id)
    return redirect(url_for("main.messages", username=partner.username))


# =========================================================
# CALLS (lightweight: call requests + call log)
# =========================================================
@main.route("/calls")
@login_required
def calls():
    logs = (
        CallLog.query
        .filter(or_(CallLog.caller_id == current_user.id, CallLog.callee_id == current_user.id))
        .order_by(CallLog.created_at.desc())
        .limit(60)
        .all()
    )
    return render_template("calls.html", logs=logs)


@main.route("/call/<username>/start", methods=["POST"])
@login_required
@limiter.limit("30/hour;5/minute")
def start_call(username):
    target = User.query.filter_by(username=username).first_or_404()
    if target.id == current_user.id:
        flash("You can't call yourself.", "warning")
        return redirect(request.referrer or url_for("main.calls"))

    if _is_blocking(current_user, target) or _is_blocked_by(current_user, target):
        flash("Action not allowed.", "danger")
        return redirect(request.referrer or url_for("main.calls"))

    log = CallLog(caller_id=current_user.id, callee_id=target.id, status="requested")
    db.session.add(log)
    db.session.commit()

    _notify(target.id, current_user.id, "call_request", {"call_id": log.id})
    flash("📞 Call request sent.", "success")
    return redirect(url_for("main.calls"))


@main.route("/call/<int:call_id>/<action>", methods=["POST"])
@login_required
def respond_call(call_id, action):
    log = CallLog.query.get_or_404(call_id)
    if current_user.id not in {log.caller_id, log.callee_id}:
        flash("Action not allowed.", "danger")
        return redirect(url_for("main.calls"))

    if action not in {"accept", "decline", "end"}:
        flash("Invalid action.", "warning")
        return redirect(url_for("main.calls"))

    if action == "accept" and current_user.id == log.callee_id:
        log.status = "accepted"
        db.session.commit()
        _notify(log.caller_id, current_user.id, "call_update", {"call_id": log.id, "status": "accepted"})
        flash("✅ Call accepted (UI-only demo).", "success")
        return redirect(url_for("main.calls"))

    if action == "decline" and current_user.id == log.callee_id:
        log.status = "declined"
        log.ended_at = datetime.utcnow()
        db.session.commit()
        _notify(log.caller_id, current_user.id, "call_update", {"call_id": log.id, "status": "declined"})
        flash("❌ Call declined.", "info")
        return redirect(url_for("main.calls"))

    if action == "end":
        log.status = "ended"
        log.ended_at = datetime.utcnow()
        db.session.commit()
        other = log.callee_id if current_user.id == log.caller_id else log.caller_id
        _notify(other, current_user.id, "call_update", {"call_id": log.id, "status": "ended"})
        flash("☎️ Call ended.", "info")
        return redirect(url_for("main.calls"))

    flash("Action not allowed.", "danger")
    return redirect(url_for("main.calls"))


# =========================================================
# NOTIFICATIONS
# =========================================================
@main.route("/notifications")
@login_required
def notifications():
    items = (
        Notification.query
        .filter_by(user_id=current_user.id)
        .order_by(Notification.created_at.desc())
        .limit(120)
        .all()
    )
    return render_template("notifications.html", items=items)


@main.route("/notifications/mark-all", methods=["POST"])
@login_required
def notifications_mark_all():
    Notification.query.filter_by(user_id=current_user.id, read=False).update({"read": True})
    db.session.commit()
    return redirect(url_for("main.notifications"))


@main.route("/api/notifications/count")
@login_required
def api_notifications_count():
    unread_notifications = Notification.query.filter_by(user_id=current_user.id, read=False).count()
    unread_messages = Message.query.filter_by(recipient_id=current_user.id, is_read=False).count()
    unread_calls = Notification.query.filter_by(user_id=current_user.id, read=False, type="call_request").count()
    return jsonify({
        "unread_notifications": unread_notifications,
        "unread_messages": unread_messages,
        "unread_calls": unread_calls,
    })


# =========================================================
# SEARCH
# =========================================================
@main.route("/search")
@login_required
def search():
    q = (request.args.get("q") or "").strip()
    users = []
    if q:
        users = (
            User.query
            .filter(or_(User.username.ilike(f"%{q}%"),
                        User.email.ilike(f"%{q}%")))
            .order_by(User.username.asc())
            .all()
        )
    return render_template("search_results.html", q=q, users=users)


# =========================================================
# SETTINGS (view/update) + PASSWORD
# =========================================================
@main.route("/settings", methods=["GET", "POST"])
@login_required
def settings():
    if current_user.settings is None:
        db.session.add(UserSettings(user=current_user))
        db.session.commit()

    s = current_user.settings

    if request.method == "POST":
        s.display_name = request.form.get("display_name") or s.display_name
        s.bio = request.form.get("bio") or ""
        s.website = request.form.get("website") or ""
        s.account_type = request.form.get("account_type") or s.account_type
        s.language = request.form.get("language") or s.language
        s.linked_facebook = request.form.get("linked_facebook") or None

        s.is_private = bool(request.form.get("is_private"))
        s.show_activity_status = bool(request.form.get("show_activity_status"))
        s.allow_story_replies = request.form.get("allow_story_replies") or s.allow_story_replies
        s.allow_tags = request.form.get("allow_tags") or s.allow_tags
        s.allow_mentions = request.form.get("allow_mentions") or s.allow_mentions
        s.post_visibility = request.form.get("post_visibility") or s.post_visibility
        s.contact_sync = bool(request.form.get("contact_sync"))
        s.ad_personalization = bool(request.form.get("ad_personalization"))

        s.notify_likes = bool(request.form.get("notify_likes"))
        s.notify_comments = bool(request.form.get("notify_comments"))
        s.notify_mentions = bool(request.form.get("notify_mentions"))
        s.notify_follows = bool(request.form.get("notify_follows"))
        s.notify_messages = bool(request.form.get("notify_messages"))
        s.notify_stories = bool(request.form.get("notify_stories"))
        s.notify_live = bool(request.form.get("notify_live"))

        s.feed_preference = request.form.get("feed_preference") or s.feed_preference
        s.comments_filter = request.form.get("comments_filter") or s.comments_filter
        s.carousel_autoplay = bool(request.form.get("carousel_autoplay"))
        try:
            s.carousel_interval_ms = int(request.form.get("carousel_interval_ms") or s.carousel_interval_ms)
        except ValueError:
            pass
        s.allow_shoppable_links = bool(request.form.get("allow_shoppable_links"))
        s.save_to_archive = bool(request.form.get("save_to_archive"))

        # Security
        s.two_factor_enabled = bool(request.form.get("two_factor_enabled"))

        s.theme = request.form.get("theme") or s.theme
        s.font_size = request.form.get("font_size") or s.font_size
        s.notif_sound = bool(request.form.get("notif_sound"))
        s.content_language = request.form.get("content_language") or s.content_language

        db.session.commit()
        flash("Settings saved.", "success")
        return redirect(url_for("main.settings"))

    return render_template("settings.html", settings=s)


@main.route("/settings/password", methods=["POST"])
@login_required
def settings_password():
    current_pw = request.form.get("current_password", "")
    new_pw = request.form.get("new_password", "")
    confirm_pw = request.form.get("confirm_password", "")

    if not current_user.check_password(current_pw):
        flash("Current password is incorrect.", "danger")
        return redirect(url_for("main.settings"))

    if not new_pw or new_pw != confirm_pw:
        flash("New passwords do not match.", "danger")
        return redirect(url_for("main.settings"))

    current_user.set_password(new_pw)
    db.session.commit()
    flash("Password updated.", "success")
    return redirect(url_for("main.settings"))


# =========================================================
# EXPLORE
# =========================================================
@main.route("/explore")
@login_required
def explore():
    posts = Post.query.order_by(Post.timestamp.desc()).limit(30).all()
    people = (
        User.query
        .filter(User.id != current_user.id)
        .order_by(User.username.asc())
        .limit(30).all()
    )
    return render_template("explore.html", posts=posts, people=people)


# =========================================================
# REPORT / BLOCK / UNBLOCK
# =========================================================
@main.route("/report", methods=["POST"])
@login_required
@limiter.limit("10/hour")
def report():
    ttype = request.form.get("target_type", "")
    tid = request.form.get("target_id", "")
    reason = (request.form.get("reason") or "").strip()[:255]

    if ttype not in {"post", "comment", "user", "message"} or not tid.isdigit():
        flash("Invalid report.", "danger")
        return redirect(request.referrer or url_for("main.home"))

    db.session.add(Report(
        reporter_id=current_user.id,
        target_type=ttype,
        target_id=int(tid),
        reason=reason
    ))
    db.session.commit()
    flash("Thanks for reporting.", "success")
    return redirect(request.referrer or url_for("main.home"))


@main.route("/block/<username>", methods=["POST"])
@login_required
@limiter.limit("30/hour")
def block_user(username):
    u = User.query.filter_by(username=username).first_or_404()
    if u.id == current_user.id:
        flash("You can't block yourself.", "warning")
        return redirect(url_for("main.user_profile", username=username))

    if not _is_blocking(current_user, u):
        db.session.add(Block(blocker_id=current_user.id, blocked_id=u.id))
        db.session.commit()

    flash(f"Blocked {u.username}.", "success")
    return redirect(url_for("main.user_profile", username=username))


@main.route("/unblock/<username>", methods=["POST"])
@login_required
def unblock_user(username):
    u = User.query.filter_by(username=username).first_or_404()
    b = Block.query.filter_by(blocker_id=current_user.id, blocked_id=u.id).first()
    if b:
        db.session.delete(b)
        db.session.commit()
    flash(f"Unblocked {u.username}.", "success")
    return redirect(url_for("main.user_profile", username=username))
