"""Auth blueprint.

Includes:
- Login/logout with lockout.
- Registration.
- Email code verification (6-digit OTP) to make the app harder to abuse.
"""

import os
import random
from datetime import datetime, timedelta

from flask import (
    Blueprint, render_template, request, redirect, url_for, flash, current_app
)
from flask_login import login_user, logout_user, login_required, current_user
from werkzeug.utils import secure_filename
from werkzeug.security import generate_password_hash, check_password_hash
from sqlalchemy.exc import IntegrityError
from flask_mail import Message as MailMessage

from app import db, limiter, mail
from app.models import User, UserSettings, EmailOTP  # Settings row on signup is nice to have
from app.security import generate_token, verify_token  # your itsdangerous helpers

# Put all auth routes under /auth to avoid conflicts
auth = Blueprint("auth", __name__, url_prefix="/auth")


# ---------------------------
# Helpers
# ---------------------------
def _save_profile_image(file_storage) -> str:
    """Save an uploaded profile image into app/static/profile_pics."""
    if not file_storage or not getattr(file_storage, "filename", ""):
        return "profile_pics/default.png"

    filename = secure_filename(file_storage.filename or "")
    if not filename:
        return "profile_pics/default.png"

    upload_dir = os.path.join("app", "static", "profile_pics")
    os.makedirs(upload_dir, exist_ok=True)

    file_path = os.path.join(upload_dir, filename)
    file_storage.save(file_path)

    return f"profile_pics/{filename}"


def _maybe_set_verified_fields(user: User) -> None:
    """Set email verified fields if present in User model."""
    if hasattr(user, "is_email_verified"):
        setattr(user, "is_email_verified", True)
    if hasattr(user, "email_verified_at"):
        setattr(user, "email_verified_at", datetime.utcnow())


def _new_otp_code() -> str:
    """Return a 6-digit code as a string."""
    return f"{random.randint(0, 999999):06d}"


def _send_email(to_email: str, subject: str, body: str) -> None:
    """Send email if SMTP is configured; otherwise log the message (dev-friendly)."""
    has_server = bool(current_app.config.get("MAIL_SERVER"))
    has_user = bool(current_app.config.get("MAIL_USERNAME"))

    if not has_server or not has_user:
        # No SMTP configuration → print to server logs so you can still test locally.
        current_app.logger.info("== EMAIL to=%s subject=%s ==\n%s", to_email, subject, body)
        return

    msg = MailMessage(subject=subject, recipients=[to_email], body=body)
    mail.send(msg)


def _create_and_send_otp(user: User, purpose: str, minutes_valid: int = 10) -> None:
    """Create an EmailOTP row and send it to the user's email."""
    code = _new_otp_code()
    otp = EmailOTP(
        user_id=user.id,
        purpose=purpose,
        code_hash=generate_password_hash(code),
        expires_at=datetime.utcnow() + timedelta(minutes=minutes_valid),
    )
    db.session.add(otp)
    db.session.commit()

    body = (
        f"Your CampusConnect verification code is: {code}\n\n"
        f"It expires in {minutes_valid} minutes. If you didn't request this, you can ignore this email."
    )
    _send_email(user.email, "Your verification code", body)


# ---------------------------
# Login / Logout
# ---------------------------
@auth.route("/login", methods=["GET", "POST"])
@limiter.limit("30/hour;10/minute", methods=["POST"])
def login():
    if current_user.is_authenticated:
        return redirect(url_for("main.home"))

    if request.method == "POST":
        username = (request.form.get("username") or "").strip()
        password = request.form.get("password") or ""

        user = User.query.filter_by(username=username).first()

        # 1) If user is locked
        if user and user.lockout_until and datetime.utcnow() < user.lockout_until:
            remaining = int((user.lockout_until - datetime.utcnow()).total_seconds() // 60) + 1
            flash(f"⏳ Too many failed attempts. Try again in {remaining} minutes.", "danger")
            return render_template("login.html")

        # 2) If credentials are correct
        if user and user.check_password(password):
            user.failed_attempts = 0
            user.lockout_until = None
            db.session.commit()

            # Require verified email before allowing login
            if hasattr(user, "is_email_verified") and not getattr(user, "is_email_verified", False):
                _create_and_send_otp(user, purpose="verify_email", minutes_valid=10)
                token = generate_token({"uid": user.id, "purpose": "verify_email"})
                flash("📩 We sent a 6‑digit code to your email. Enter it to verify your account.", "info")
                return redirect(url_for("auth.verify_code", token=token))

            # Optional: login 2FA if enabled in settings
            try:
                if getattr(user, "settings", None) and getattr(user.settings, "two_factor_enabled", False):
                    _create_and_send_otp(user, purpose="login", minutes_valid=10)
                    token = generate_token({"uid": user.id, "purpose": "login"})
                    flash("🔐 Two‑factor enabled. Enter the code sent to your email.", "info")
                    return redirect(url_for("auth.verify_code", token=token, next=request.args.get("next") or ""))
            except Exception:
                pass

            login_user(user)
            flash("✅ Welcome back!", "success")
            next_url = request.args.get("next")
            return redirect(next_url or url_for("main.home"))

        # 3) If login failed
        if user:
            user.failed_attempts += 1
            if user.failed_attempts >= 5:
                user.lockout_until = datetime.utcnow() + timedelta(minutes=5)
                flash("🚨 Account locked for 5 minutes due to failed attempts.", "danger")
            db.session.commit()

        flash("❌ Invalid username or password.", "danger")
        return render_template("login.html")

    return render_template("login.html")


@auth.route("/logout")
@login_required
def logout():
    logout_user()
    flash("You’ve been logged out.", "info")
    return redirect(url_for("auth.login"))


# ---------------------------
# Register + (optional) email verification link
# ---------------------------
@auth.route("/register", methods=["GET", "POST"])
@limiter.limit("30/hour;8/minute", methods=["POST"])
def register():
    if current_user.is_authenticated:
        return redirect(url_for("main.home"))

    if request.method == "POST":
        username = (request.form.get("username") or "").strip()
        email = (request.form.get("email") or "").strip().lower()
        password = request.form.get("password") or ""

        if not username or not email or not password:
            flash("⚠️ Please fill in all fields.", "danger")
            return render_template("register.html")

        # Ensure unique username/email
        exists = User.query.filter((User.username == username) | (User.email == email)).first()
        if exists:
            flash("⚠️ Username or email already exists.", "danger")
            return render_template("register.html")

        # Optional profile image
        rel_image_path = _save_profile_image(request.files.get("profile_image"))

        # Create user
        user = User(username=username, email=email, profile_image=rel_image_path)
        user.set_password(password)

        try:
            db.session.add(user)
            db.session.flush()  # get user.id
            if "UserSettings" in globals() and not getattr(user, "settings", None):
                db.session.add(UserSettings(user=user))
            db.session.commit()
        except IntegrityError:
            db.session.rollback()
            flash("⚠️ Username or email already exists.", "danger")
            return render_template("register.html")

        # Send 6-digit email code for verification
        _create_and_send_otp(user, purpose="verify_email", minutes_valid=10)
        token = generate_token({"uid": user.id, "purpose": "verify_email"})
        flash("🎉 Account created! We sent a verification code to your email.", "success")
        return redirect(url_for("auth.verify_code", token=token))

    return render_template("register.html")


@auth.route("/verify")
def verify_email():
    token = request.args.get("token", "")
    data = verify_token(token, max_age=60 * 60 * 24)  # 24h
    if not data or data.get("action") != "verify":
        flash("❌ Invalid or expired verification link.", "danger")
        return redirect(url_for("main.home"))

    user = User.query.get_or_404(data["uid"])
    _maybe_set_verified_fields(user)
    db.session.commit()
    flash("📩 Email verified. Welcome!", "success")
    return redirect(url_for("main.home"))


# ---------------------------
# Email code verification (OTP)
# ---------------------------
@auth.route("/verify-code", methods=["GET", "POST"])
@limiter.limit("20/hour;6/minute", methods=["POST"])
def verify_code():
    """Verify a 6-digit code for either email verification or 2FA login."""
    token = request.args.get("token", "")
    next_url = request.args.get("next") or ""

    data = verify_token(token, max_age=60 * 60)  # 1 hour
    if not data or not data.get("uid"):
        flash("❌ Invalid or expired verification session.", "danger")
        return redirect(url_for("auth.login"))

    user = User.query.get_or_404(int(data["uid"]))
    purpose = data.get("purpose") or data.get("action") or "verify_email"

    if request.method == "POST":
        code = (request.form.get("code") or "").strip()
        if not code.isdigit() or len(code) != 6:
            flash("⚠️ Enter the 6-digit code.", "warning")
            return render_template("verify_code.html", token=token, purpose=purpose)

        otp = (
            EmailOTP.query
            .filter_by(user_id=user.id, purpose=purpose, used=False)
            .order_by(EmailOTP.created_at.desc())
            .first()
        )
        if not otp or not otp.is_active():
            flash("❌ Code expired. Please resend a new code.", "danger")
            return render_template("verify_code.html", token=token, purpose=purpose)

        # brute-force resistance
        otp.attempts = (otp.attempts or 0) + 1
        if otp.attempts > 6:
            otp.used = True
            db.session.commit()
            flash("🚫 Too many attempts. Please resend a new code.", "danger")
            return render_template("verify_code.html", token=token, purpose=purpose)

        if not check_password_hash(otp.code_hash, code):
            db.session.commit()
            flash("❌ Incorrect code.", "danger")
            return render_template("verify_code.html", token=token, purpose=purpose)

        otp.used = True

        if purpose == "verify_email":
            _maybe_set_verified_fields(user)
            db.session.commit()
            login_user(user)
            flash("✅ Email verified. Welcome!", "success")
            return redirect(url_for("main.home"))

        if purpose == "login":
            db.session.commit()
            login_user(user)
            flash("✅ Verified. You're logged in.", "success")
            return redirect(next_url or url_for("main.home"))

        db.session.commit()
        flash("✅ Done.", "success")
        return redirect(url_for("main.home"))

    return render_template("verify_code.html", token=token, purpose=purpose)


@auth.route("/resend-code")
@limiter.limit("10/hour;3/minute")
def resend_code():
    token = request.args.get("token", "")
    data = verify_token(token, max_age=60 * 60)
    if not data or not data.get("uid"):
        flash("❌ Invalid or expired session.", "danger")
        return redirect(url_for("auth.login"))

    user = User.query.get_or_404(int(data["uid"]))
    purpose = data.get("purpose") or data.get("action") or "verify_email"
    _create_and_send_otp(user, purpose=purpose, minutes_valid=10)
    flash("📩 New code sent. Check your email.", "info")
    return redirect(url_for("auth.verify_code", token=token, next=request.args.get("next") or ""))


# ---------------------------
# Password reset (request + reset)
# ---------------------------
@auth.route("/reset-request", methods=["GET", "POST"])
@limiter.limit("5/hour")
def reset_request():
    if request.method == "POST":
        email = (request.form.get("email") or "").strip().lower()
        user = User.query.filter_by(email=email).first()
        if user:
            token = generate_token({"uid": user.id, "action": "reset"})
            reset_link = url_for("auth.reset_password", token=token, _external=True)
            _send_email(user.email, "Reset your password", f"Open this link to reset your password:\n\n{reset_link}\n\nIf you didn't request this, ignore this email.")
        flash("📨 If that email exists, a reset link has been sent.", "info")
        return redirect(url_for("auth.login"))

    return render_template("reset_request.html")


@auth.route("/reset", methods=["GET", "POST"])
@limiter.limit("5/hour")
def reset_password():
    token = request.args.get("token", "")
    data = verify_token(token, max_age=60 * 60)  # 1h
    if not data or data.get("action") != "reset":
        flash("❌ Invalid or expired reset link.", "danger")
        return redirect(url_for("auth.login"))

    user = User.query.get_or_404(data["uid"])

    if request.method == "POST":
        pw = request.form.get("password", "")
        pw2 = request.form.get("confirm", "")
        if not pw or pw != pw2:
            flash("⚠️ Passwords do not match.", "danger")
            return redirect(request.url)

        user.set_password(pw)
        db.session.commit()
        flash("🔑 Password updated. You can log in.", "success")
        return redirect(url_for("auth.login"))

    return render_template("reset_form.html")
