# app/events.py
from flask import Blueprint, render_template, request, redirect, url_for, flash, send_file
from flask_login import login_required, current_user
import qrcode
import io
from . import db
from .models import CampusEvent, EventAttendance

events = Blueprint("events", __name__, url_prefix="/events")

# Show all events
@events.route("/")
@login_required
def list_events():
    all_events = CampusEvent.query.all()
    return render_template("events.html", events=all_events)

# Create new event
@events.route("/create", methods=["POST"])
@login_required
def create_event():
    name = request.form.get("name")
    date = request.form.get("date")
    if not name or not date:
        flash("Name and date required", "warning")
        return redirect(url_for("events.list_events"))

    new_event = CampusEvent(name=name, date=date, creator_id=current_user.id)
    db.session.add(new_event)
    db.session.commit()
    flash("Event created!", "success")
    return redirect(url_for("events.list_events"))

# Generate QR code for event
@events.route("/<int:event_id>/qr")
@login_required
def event_qr(event_id):
    checkin_url = url_for("events.checkin", event_id=event_id, _external=True)
    img = qrcode.make(checkin_url)

    buf = io.BytesIO()
    img.save(buf, format="PNG")
    buf.seek(0)
    return send_file(buf, mimetype="image/png")

# Check-in endpoint
@events.route("/<int:event_id>/checkin")
@login_required
def checkin(event_id):
    already = EventAttendance.query.filter_by(event_id=event_id, user_id=current_user.id).first()
    if already:
        flash("You already checked in!", "info")
    else:
        record = EventAttendance(event_id=event_id, user_id=current_user.id)
        db.session.add(record)
        db.session.commit()
        flash("Check-in successful ✅", "success")
    return redirect(url_for("events.list_events"))
