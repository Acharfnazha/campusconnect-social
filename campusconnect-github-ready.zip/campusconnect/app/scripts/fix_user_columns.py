# scripts/fix_user_columns.py
from app import db
from sqlalchemy import text
import sqlite3, os

uri = str(db.engine.url)
print("DB URI:", uri)

if not uri.startswith("sqlite:///"):
    raise SystemExit("This fixer is for SQLite only. If you use Postgres/MySQL, run proper migrations.")

db_path = uri.replace("sqlite:///", "")
assert os.path.exists(db_path), f"DB file not found: {db_path}"
print("DB PATH:", db_path)

con = sqlite3.connect(db_path)
cols = [row[1] for row in con.execute("PRAGMA table_info(user);").fetchall()]
print("Columns before:", cols)

con.close()

with db.engine.begin() as conn:
    if "failed_attempts" not in cols:
        print("-> Adding failed_attempts …")
        conn.execute(text("ALTER TABLE user ADD COLUMN failed_attempts INTEGER NOT NULL DEFAULT 0"))
    else:
        print("-> failed_attempts already exists")

    if "lockout_until" not in cols:
        print("-> Adding lockout_until …")
        conn.execute(text("ALTER TABLE user ADD COLUMN lockout_until TIMESTAMP NULL"))
    else:
        print("-> lockout_until already exists")

# verify
con = sqlite3.connect(db_path)
cols_after = [row[1] for row in con.execute("PRAGMA table_info(user);").fetchall()]
print("Columns after:", cols_after)
con.close()
print("✅ Done")
