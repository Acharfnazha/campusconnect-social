BAD_WORDS = {"badword", "worseword"}  # extend as you like

def clean_text(text: str) -> str:
    if not text:
        return text
    out = text
    for w in BAD_WORDS:
        out = out.replace(w, "*" * len(w))
    return out

def has_profanity(text: str) -> bool:
    if not text:
        return False
    lw = text.lower()
    return any(b in lw for b in BAD_WORDS)

