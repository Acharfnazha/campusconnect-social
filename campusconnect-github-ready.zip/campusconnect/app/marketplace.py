# app/marketplace.py
from flask import Blueprint, render_template, request, redirect, url_for, flash, current_app, send_from_directory
from flask_login import login_required, current_user
from werkzeug.utils import secure_filename
import os
from . import db
from .models import MarketplaceItem, ItemCategory, ItemImage

marketplace = Blueprint("marketplace", __name__, url_prefix="/market")

ALLOWED_EXTENSIONS = {"png", "jpg", "jpeg", "gif", "webp"}

def allowed_file(filename):
    return "." in filename and filename.rsplit(".", 1)[1].lower() in ALLOWED_EXTENSIONS

@marketplace.route("/")
def index():
    q = request.args.get("q", "").strip()
    cat = request.args.get("cat", type=int)
    items = MarketplaceItem.query.filter_by(is_sold=False)
    if q:
        items = items.filter(MarketplaceItem.title.ilike(f"%{q}%"))
    if cat:
        items = items.filter_by(category_id=cat)
    items = items.order_by(MarketplaceItem.created_at.desc()).all()
    categories = ItemCategory.query.order_by(ItemCategory.name).all()
    return render_template("market/index.html", items=items, categories=categories, q=q, cat=cat)

@marketplace.route("/item/<int:item_id>")
def item_detail(item_id):
    item = MarketplaceItem.query.get_or_404(item_id)
    return render_template("market/detail.html", item=item)

@marketplace.route("/sell", methods=["GET", "POST"])
@login_required
def sell():
    if request.method == "POST":
        title = request.form.get("title", "").strip()
        description = request.form.get("description", "").strip()
        price = request.form.get("price", type=float)
        category_id = request.form.get("category_id", type=int)

        if not title or price is None:
            flash("Title and price are required.", "danger")
            return redirect(url_for("marketplace.sell"))

        item = MarketplaceItem(
            title=title,
            description=description,
            price=price,
            seller_id=current_user.id,
            category_id=category_id if category_id else None,
        )
        db.session.add(item)
        db.session.commit()

        # handle images
        files = request.files.getlist("images")
        upload_folder = os.path.join(current_app.instance_path, "uploads", "market")
        os.makedirs(upload_folder, exist_ok=True)

        for f in files:
            if f and allowed_file(f.filename):
                fname = secure_filename(f.filename)
                # make unique name
                base, ext = os.path.splitext(fname)
                unique_name = f"{item.id}_{base}{ext}"
                path = os.path.join(upload_folder, unique_name)
                f.save(path)
                db.session.add(ItemImage(filename=unique_name, item_id=item.id))

        db.session.commit()
        flash("Item listed successfully!", "success")
        return redirect(url_for("marketplace.item_detail", item_id=item.id))

    categories = ItemCategory.query.order_by(ItemCategory.name).all()
    return render_template("market/sell.html", categories=categories)

@marketplace.route("/mine")
@login_required
def my_items():
    items = MarketplaceItem.query.filter_by(seller_id=current_user.id).order_by(MarketplaceItem.created_at.desc()).all()
    return render_template("market/mine.html", items=items)

@marketplace.route("/item/<int:item_id>/mark_sold", methods=["POST"])
@login_required
def mark_sold(item_id):
    item = MarketplaceItem.query.get_or_404(item_id)
    if item.seller_id != current_user.id:
        flash("Not authorized.", "danger")
        return redirect(url_for("marketplace.item_detail", item_id=item.id))
    item.is_sold = True
    db.session.commit()
    flash("Marked as sold.", "success")
    return redirect(url_for("marketplace.item_detail", item_id=item.id))

# serve uploaded images
@marketplace.route("/uploads/<path:filename>")
def market_uploads(filename):
    folder = os.path.join(current_app.instance_path, "uploads", "market")
    return send_from_directory(folder, filename, as_attachment=False)
