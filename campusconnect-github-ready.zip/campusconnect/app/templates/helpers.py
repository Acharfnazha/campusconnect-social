def notify(user_id, actor_id, typ, payload=None):
    n = Notification(user_id=user_id, actor_id=actor_id, type=typ, payload=payload or {})
    db.session.add(n)
    db.session.commit()
