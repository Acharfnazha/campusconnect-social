# app/studybuddy.py
from flask import Blueprint, render_template, request, current_app

studybuddy = Blueprint("studybuddy", __name__, template_folder="templates")

def _simple_summary(text: str) -> str:
    """Naive fallback summarizer: first 3 sentences or first 300 chars."""
    import re
    if not text:
        return ""
    parts = re.split(r'(?<=[.!?])\s+', text.strip())
    if len(parts) <= 3:
        return text.strip()
    return " ".join(parts[:3])[:1000]

@studybuddy.route("/studybuddy", methods=["GET", "POST"])
def study_buddy():
    summary = None
    error = None
    if request.method == "POST":
        notes = (request.form.get("notes") or "").strip()
        if notes:
            # Try OpenAI if configured; otherwise use fallback
            try:
                import openai
                api_key = current_app.config.get("OPENAI_API_KEY") or None
                if api_key:
                    openai.api_key = api_key
                    resp = openai.Completion.create(
                        engine="text-davinci-003",
                        prompt=f"Summarize these notes concisely:\n\n{notes}",
                        max_tokens=160,
                        temperature=0.3
                    )
                    summary = resp.choices[0].text.strip()
                else:
                    # no API key → fallback
                    summary = _simple_summary(notes)
            except Exception as e:
                # any failure → fallback summary and show minimal error info
                summary = _simple_summary(notes)
                error = f"AI unavailable, showing fallback summary. ({e})"
    return render_template("studybuddy.html", summary=summary, error=error)
