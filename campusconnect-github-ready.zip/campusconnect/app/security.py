from itsdangerous import URLSafeTimedSerializer, BadSignature, SignatureExpired
from flask import current_app

def _ts():
    # A serializer for signed, timed tokens
    return URLSafeTimedSerializer(current_app.config['SECRET_KEY'], salt="email")

def generate_token(payload: dict) -> str:
    return _ts().dumps(payload)

def verify_token(token: str, max_age: int = 3600):
    try:
        return _ts().loads(token, max_age=max_age)
    except (SignatureExpired, BadSignature):
        return None
