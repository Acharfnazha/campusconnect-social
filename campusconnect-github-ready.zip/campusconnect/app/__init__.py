# app/__init__.py
import os
import secrets
from flask import Flask, redirect, url_for
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager
from flask_migrate import Migrate
from flask_limiter import Limiter
from flask_limiter.util import get_remote_address
from flask_wtf import CSRFProtect
from flask_mail import Mail

# -----------------------
# Core extensions
# -----------------------
db = SQLAlchemy()
migrate = Migrate()
limiter = Limiter(key_func=get_remote_address, storage_uri="memory://")
csrf = CSRFProtect()
mail = Mail()

def create_app():
    app = Flask(__name__)

    # -----------------------
    # Config
    # -----------------------
    # Instance folder is the safe default place for SQLite and runtime files
    os.makedirs(app.instance_path, exist_ok=True)
    db_path = os.path.join(app.instance_path, "database.db")

    app.config.update(
        # Use env var if provided, otherwise generate a random secret for local dev
        SECRET_KEY=os.environ.get("SECRET_KEY") or secrets.token_urlsafe(32),
        SQLALCHEMY_DATABASE_URI=os.environ.get("DATABASE_URL") or f"sqlite:///{db_path}",
        SQLALCHEMY_TRACK_MODIFICATIONS=False,
        WTF_CSRF_ENABLED=True,
        WTF_CSRF_CHECK_DEFAULT=True,
        SESSION_COOKIE_HTTPONLY=True,
        SESSION_COOKIE_SAMESITE="Lax",
        # In production behind HTTPS set this to True (or export SESSION_COOKIE_SECURE=1)
        SESSION_COOKIE_SECURE=(os.environ.get("SESSION_COOKIE_SECURE") == "1"),
        TEMPLATES_AUTO_RELOAD=True,
        JSON_SORT_KEYS=False,

        # Mail (for email verification codes)
        MAIL_SERVER=os.environ.get("MAIL_SERVER", ""),
        MAIL_PORT=int(os.environ.get("MAIL_PORT", "587")),
        MAIL_USE_TLS=(os.environ.get("MAIL_USE_TLS", "1") == "1"),
        MAIL_USE_SSL=(os.environ.get("MAIL_USE_SSL", "0") == "1"),
        MAIL_USERNAME=os.environ.get("MAIL_USERNAME", ""),
        MAIL_PASSWORD=os.environ.get("MAIL_PASSWORD", ""),
        MAIL_DEFAULT_SENDER=os.environ.get("MAIL_DEFAULT_SENDER", "CampusConnect <no-reply@localhost>"),
    )

    # -----------------------
    # Init extensions
    # -----------------------
    db.init_app(app)
    migrate.init_app(app, db)
    limiter.init_app(app)
    csrf.init_app(app)
    mail.init_app(app)

    # -----------------------
    # Login manager
    # -----------------------
    login_manager = LoginManager()
    login_manager.login_view = "auth.login"
    login_manager.init_app(app)

    # Import models AFTER db is bound
    from .models import User, Message, ProfileView

    @login_manager.user_loader
    def load_user(user_id: str):
        try:
            return User.query.get(int(user_id))
        except Exception:
            return None

    # -----------------------
    # Security headers (lightweight defaults)
    # -----------------------
    @app.after_request
    def _security_headers(resp):
        resp.headers.setdefault("X-Content-Type-Options", "nosniff")
        resp.headers.setdefault("X-Frame-Options", "SAMEORIGIN")
        resp.headers.setdefault("Referrer-Policy", "strict-origin-when-cross-origin")
        return resp

    # -----------------------
    # Register blueprints
    # -----------------------
    from .routes import main
    from .auth import auth
    app.register_blueprint(main)
    app.register_blueprint(auth)

    # Optional feature blueprints (won't crash if missing)
    for bp_path, bp_name in [
        (".studybuddy", "studybuddy"),
        (".tutoring", "tutoring"),
        (".events", "events"),
        (".marketplace", "marketplace"),
    ]:
        try:
            mod = __import__(f"app{bp_path}", fromlist=[bp_name])
            app.register_blueprint(getattr(mod, bp_name))
        except Exception as e:
            app.logger.info(f"Skipped optional blueprint {bp_name}: {e}")

    # -----------------------
    # Inject unread counters globally
    # -----------------------
    @app.context_processor
    def inject_unread_counts():
        from flask_login import current_user

        if not getattr(current_user, "is_authenticated", False):
            return dict(unread_messages_count=0, unread_views_count=0, unread_notifications_count=0, unread_calls_count=0)

        unread_messages = Message.query.filter_by(
            recipient_id=current_user.id, is_read=False
        ).count()

        try:
            unread_views = ProfileView.query.filter_by(
                viewed_id=current_user.id, seen=False
            ).count()
        except Exception:
            unread_views = 0

        # Notifications (likes, follows, messages, calls, etc.)
        try:
            from .models import Notification  # imported late to avoid circular
            unread_notifications = Notification.query.filter_by(user_id=current_user.id, read=False).count()
            unread_calls = Notification.query.filter_by(user_id=current_user.id, read=False, type="call_request").count()
        except Exception:
            unread_notifications = 0
            unread_calls = 0

        return dict(
            unread_messages_count=unread_messages,
            unread_views_count=unread_views,
            unread_notifications_count=unread_notifications,
            unread_calls_count=unread_calls,
        )

    # -----------------------
    # Optional limiter filter
    # -----------------------
    @limiter.request_filter
    def allow_health_checks():
        return False  # Example: bypass /health if added

    # -----------------------
    # Friendly 404
    # -----------------------
    @app.errorhandler(404)
    def not_found(e):
        return redirect(url_for("main.home"))

    return app
