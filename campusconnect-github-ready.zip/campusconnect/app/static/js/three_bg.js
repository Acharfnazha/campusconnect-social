/*
  Minimal Three.js animated background.
  - No external assets
  - "3D" particle field behind auth screens
*/

(function () {
  const canvas = document.getElementById('three-bg');
  if (!canvas || typeof THREE === 'undefined') return;

  const renderer = new THREE.WebGLRenderer({ canvas, antialias: true, alpha: true });
  renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));

  const scene = new THREE.Scene();

  const camera = new THREE.PerspectiveCamera(55, 1, 0.1, 100);
  camera.position.z = 10;

  // Soft lights
  const ambient = new THREE.AmbientLight(0xffffff, 0.6);
  scene.add(ambient);
  const dir = new THREE.DirectionalLight(0xffffff, 0.8);
  dir.position.set(5, 8, 6);
  scene.add(dir);

  // Points geometry
  const count = 1200;
  const positions = new Float32Array(count * 3);
  const speeds = new Float32Array(count);

  for (let i = 0; i < count; i++) {
    const i3 = i * 3;
    // spread points in a box
    positions[i3 + 0] = (Math.random() - 0.5) * 22;
    positions[i3 + 1] = (Math.random() - 0.5) * 14;
    positions[i3 + 2] = (Math.random() - 0.5) * 18;
    speeds[i] = 0.25 + Math.random() * 0.75;
  }

  const geom = new THREE.BufferGeometry();
  geom.setAttribute('position', new THREE.BufferAttribute(positions, 3));

  const mat = new THREE.PointsMaterial({
    color: 0xffffff,
    size: 0.03,
    transparent: true,
    opacity: 0.85,
    depthWrite: false,
  });

  const points = new THREE.Points(geom, mat);
  scene.add(points);

  // A couple of floating "orbs" (simple spheres) for extra depth
  const orbMat = new THREE.MeshStandardMaterial({
    color: 0x3b82f6,
    roughness: 0.35,
    metalness: 0.12,
    transparent: true,
    opacity: 0.35,
  });
  const orb1 = new THREE.Mesh(new THREE.SphereGeometry(1.2, 36, 36), orbMat);
  const orb2 = new THREE.Mesh(new THREE.SphereGeometry(0.8, 36, 36), orbMat.clone());
  orb2.material.color.setHex(0x8b5cf6);
  orb1.position.set(-3.2, 1.2, -3);
  orb2.position.set(3.6, -0.8, -5);
  scene.add(orb1, orb2);

  function resize() {
    const w = canvas.clientWidth || window.innerWidth;
    const h = canvas.clientHeight || window.innerHeight;
    renderer.setSize(w, h, false);
    camera.aspect = w / h;
    camera.updateProjectionMatrix();
  }
  resize();
  window.addEventListener('resize', resize);

  let t0 = performance.now();
  function animate(now) {
    const dt = Math.min((now - t0) / 1000, 0.05);
    t0 = now;

    // gentle rotation
    points.rotation.y += dt * 0.08;
    points.rotation.x += dt * 0.03;

    // slow drift in Z for a "moving through space" feel
    const pos = geom.attributes.position;
    for (let i = 0; i < count; i++) {
      const i3 = i * 3;
      pos.array[i3 + 2] += dt * speeds[i] * 0.55;
      if (pos.array[i3 + 2] > 9) pos.array[i3 + 2] = -9;
    }
    pos.needsUpdate = true;

    // floating orbs
    const tt = now * 0.0005;
    orb1.position.y = 1.2 + Math.sin(tt * 1.2) * 0.35;
    orb2.position.x = 3.6 + Math.cos(tt * 1.0) * 0.45;
    orb2.position.y = -0.8 + Math.sin(tt * 0.9) * 0.25;

    renderer.render(scene, camera);
    requestAnimationFrame(animate);
  }
  requestAnimationFrame(animate);
})();
