from app import db
from flask_login import UserMixin
from werkzeug.security import generate_password_hash, check_password_hash
from datetime import datetime, timedelta
from sqlalchemy.orm import backref  # needed for backref(...)
from sqlalchemy import text, JSON


# ---------------------------------
# Followers association table
#  - Add primary key on both columns to prevent duplicates
#  - Add ondelete="CASCADE" so rows clean up if users are removed
# ---------------------------------
follows = db.Table(
    'follows',
    db.Column('follower_id', db.Integer, db.ForeignKey('user.id', ondelete="CASCADE"), primary_key=True),
    db.Column('followed_id', db.Integer, db.ForeignKey('user.id', ondelete="CASCADE"), primary_key=True)
)


# ---------------------------------
# User
# ---------------------------------
class User(UserMixin, db.Model):
    __tablename__ = 'user'
    __table_args__ = {'extend_existing': True}  # kept as requested

    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(150), unique=True, nullable=False, index=True)
    email = db.Column(db.String(150), unique=True, nullable=False, index=True)
    password_hash = db.Column(db.String(256), nullable=False)
    profile_image = db.Column(db.String(300), default='profile_pics/default.png')

    # 📧 Email verification
    is_email_verified = db.Column(db.Boolean, nullable=False, server_default=text("0"), index=True)
    email_verified_at = db.Column(db.DateTime, nullable=True)

    # 🔒 Security fields (use NOT NULL + server_default for smooth migration of existing rows)
    failed_attempts = db.Column(db.Integer, nullable=False, server_default=text("0"))
    lockout_until = db.Column(db.DateTime, nullable=True)

    posts = db.relationship('Post', back_populates='user', lazy=True)
    likes = db.relationship('Like', backref='user', lazy=True)
    comments = db.relationship('Comment', backref='user', lazy=True)

    # follow relationships
    followed = db.relationship(
        'User', secondary=follows,
        primaryjoin=(follows.c.follower_id == id),
        secondaryjoin=(follows.c.followed_id == id),
        backref=db.backref('followers', lazy='dynamic'),
        lazy='dynamic'
    )

    # password helpers
    def set_password(self, password: str) -> None:
        self.password_hash = generate_password_hash(password)

    def check_password(self, password: str) -> bool:
        return check_password_hash(self.password_hash, password)

    # follow helpers
    def follow(self, user: "User") -> None:
        if not self.is_following(user):
            self.followed.append(user)

    def unfollow(self, user: "User") -> None:
        if self.is_following(user):
            self.followed.remove(user)

    def is_following(self, user: "User") -> bool:
        return self.followed.filter(follows.c.followed_id == user.id).count() > 0

    def __repr__(self) -> str:
        return f"<User {self.username}>"


# ---------------------------------
# Email OTP codes (verify email / login 2FA)
# ---------------------------------
class EmailOTP(db.Model):
    __tablename__ = 'email_otp'

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id', ondelete="CASCADE"), nullable=False, index=True)
    purpose = db.Column(db.String(20), nullable=False, index=True)  # verify_email, login
    code_hash = db.Column(db.String(256), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow, index=True)
    expires_at = db.Column(db.DateTime, nullable=False, index=True)
    attempts = db.Column(db.Integer, nullable=False, server_default=text("0"))
    used = db.Column(db.Boolean, nullable=False, server_default=text("0"), index=True)

    user = db.relationship('User', backref=db.backref('email_otps', lazy=True, cascade="all, delete-orphan"))

    def is_active(self) -> bool:
        return (not self.used) and datetime.utcnow() < self.expires_at


# ---------------------------------
# Calls (lightweight: request + logs)
# ---------------------------------
class CallLog(db.Model):
    __tablename__ = 'call_log'

    id = db.Column(db.Integer, primary_key=True)
    caller_id = db.Column(db.Integer, db.ForeignKey('user.id', ondelete="CASCADE"), nullable=False, index=True)
    callee_id = db.Column(db.Integer, db.ForeignKey('user.id', ondelete="CASCADE"), nullable=False, index=True)
    status = db.Column(db.String(20), default="requested", index=True)  # requested/accepted/declined/missed/ended
    created_at = db.Column(db.DateTime, default=datetime.utcnow, index=True)
    ended_at = db.Column(db.DateTime, nullable=True)

    caller = db.relationship('User', foreign_keys=[caller_id])
    callee = db.relationship('User', foreign_keys=[callee_id])


# ---------------------------------
# User Settings
# ---------------------------------
class UserSettings(db.Model):
    __tablename__ = 'user_settings'

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id', ondelete="CASCADE"), unique=True, nullable=False)

    # Profile / account info
    display_name = db.Column(db.String(150))
    bio = db.Column(db.Text)
    website = db.Column(db.String(255))
    account_type = db.Column(db.String(20), default="personal")  # personal, creator, business
    language = db.Column(db.String(10), default="en")
    linked_facebook = db.Column(db.String(255))

    # Privacy
    is_private = db.Column(db.Boolean, default=False)
    show_activity_status = db.Column(db.Boolean, default=True)
    allow_story_replies = db.Column(db.String(20), default="everyone")
    allow_tags = db.Column(db.String(20), default="everyone")
    allow_mentions = db.Column(db.String(20), default="everyone")
    post_visibility = db.Column(db.String(20), default="everyone")
    contact_sync = db.Column(db.Boolean, default=False)
    ad_personalization = db.Column(db.Boolean, default=True)

    # Notifications
    notify_likes = db.Column(db.Boolean, default=True)
    notify_comments = db.Column(db.Boolean, default=True)
    notify_mentions = db.Column(db.Boolean, default=True)
    notify_follows = db.Column(db.Boolean, default=True)
    notify_messages = db.Column(db.Boolean, default=True)
    notify_stories = db.Column(db.Boolean, default=True)
    notify_live = db.Column(db.Boolean, default=True)

    # Content controls
    feed_preference = db.Column(db.String(20), default="balanced")
    comments_filter = db.Column(db.String(20), default="off")
    carousel_autoplay = db.Column(db.Boolean, default=True)
    carousel_interval_ms = db.Column(db.Integer, default=3500)
    allow_shoppable_links = db.Column(db.Boolean, default=False)
    save_to_archive = db.Column(db.Boolean, default=True)

    # Security
    two_factor_enabled = db.Column(db.Boolean, default=False)

    # Customization
    theme = db.Column(db.String(20), default="light")
    font_size = db.Column(db.String(10), default="medium")
    notif_sound = db.Column(db.Boolean, default=True)
    content_language = db.Column(db.String(10), default="auto")

    # one-to-one
    user = db.relationship(
        'User',
        backref=backref('settings', uselist=False, cascade="all, delete-orphan")
    )

    def __repr__(self) -> str:
        return f"<UserSettings user_id={self.user_id}>"


# ---------------------------------
# Posts / Likes / Comments
# ---------------------------------
class Post(db.Model):
    __tablename__ = 'post'

    id = db.Column(db.Integer, primary_key=True)
    content = db.Column(db.Text, nullable=False)
    image = db.Column(db.String(300))
    timestamp = db.Column(db.DateTime, default=datetime.utcnow, index=True)

    user_id = db.Column(db.Integer, db.ForeignKey('user.id', ondelete="CASCADE"), nullable=False, index=True)
    user = db.relationship('User', back_populates='posts')

    likes = db.relationship('Like', backref='post', lazy=True, cascade="all, delete-orphan")
    comments = db.relationship('Comment', backref='post', lazy=True, cascade="all, delete-orphan")

    def __repr__(self) -> str:
        return f"<Post id={self.id} by={self.user_id}>"


class Like(db.Model):
    __tablename__ = 'like'

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id', ondelete="CASCADE"), nullable=False, index=True)
    post_id = db.Column(db.Integer, db.ForeignKey('post.id', ondelete="CASCADE"), nullable=False, index=True)

    # prevent duplicate likes per (user, post)
    __table_args__ = (db.UniqueConstraint('user_id', 'post_id', name='uq_like_once'),)

    def __repr__(self) -> str:
        return f"<Like user={self.user_id} post={self.post_id}>"


class Comment(db.Model):
    __tablename__ = 'comment'

    id = db.Column(db.Integer, primary_key=True)
    content = db.Column(db.Text, nullable=False)
    timestamp = db.Column(db.DateTime, default=datetime.utcnow, index=True)

    user_id = db.Column(db.Integer, db.ForeignKey('user.id', ondelete="CASCADE"), index=True)
    post_id = db.Column(db.Integer, db.ForeignKey('post.id', ondelete="CASCADE"), index=True)

    def __repr__(self) -> str:
        return f"<Comment id={self.id} post={self.post_id}>"


# ---------------------------------
# Profile Views
# ---------------------------------
class ProfileView(db.Model):
    __tablename__ = 'profile_view'

    id = db.Column(db.Integer, primary_key=True)
    viewer_id = db.Column(db.Integer, db.ForeignKey('user.id', ondelete="CASCADE"), index=True)
    viewed_id = db.Column(db.Integer, db.ForeignKey('user.id', ondelete="CASCADE"), index=True)
    timestamp = db.Column(db.DateTime, default=datetime.utcnow, index=True)
    seen = db.Column(db.Boolean, default=False)

    viewer = db.relationship('User', foreign_keys=[viewer_id], backref='views_made')
    viewed = db.relationship('User', foreign_keys=[viewed_id], backref='views_received')

    def __repr__(self) -> str:
        return f"<ProfileView {self.viewer_id}->{self.viewed_id} at {self.timestamp}>"


# ---------------------------------
# Direct Messages
# ---------------------------------
class Message(db.Model):
    __tablename__ = 'message'

    id = db.Column(db.Integer, primary_key=True)
    sender_id = db.Column(db.Integer, db.ForeignKey('user.id', ondelete="CASCADE"), nullable=False, index=True)
    recipient_id = db.Column(db.Integer, db.ForeignKey('user.id', ondelete="CASCADE"), nullable=False, index=True)
    content = db.Column(db.Text, nullable=False)
    timestamp = db.Column(db.DateTime, default=datetime.utcnow, index=True)
    is_read = db.Column(db.Boolean, default=False, index=True)

    sender = db.relationship('User', foreign_keys=[sender_id], backref='messages_sent')
    recipient = db.relationship('User', foreign_keys=[recipient_id], backref='messages_received')

    def __repr__(self) -> str:
        return f"<Message {self.sender_id}->{self.recipient_id} at {self.timestamp}>"


# ---------------------------------
# Stories + Views (24h)
# ---------------------------------
class Story(db.Model):
    __tablename__ = 'story'

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id', ondelete="CASCADE"), nullable=False, index=True)
    media_path = db.Column(db.String(300), nullable=False)
    media_type = db.Column(db.String(10), nullable=False)
    caption = db.Column(db.String(255))
    created_at = db.Column(db.DateTime, default=datetime.utcnow, index=True)
    expires_at = db.Column(db.DateTime, index=True)

    user = db.relationship('User', backref='stories', lazy=True)

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        if not self.expires_at:
            base = self.created_at or datetime.utcnow()
            self.expires_at = base + timedelta(hours=24)

    def is_active(self) -> bool:
        return (self.expires_at or datetime.utcnow()) > datetime.utcnow()

    def __repr__(self) -> str:
        return f"<Story id={self.id} user={self.user_id} {self.media_type}>"


class Report(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    reporter_id = db.Column(db.Integer, db.ForeignKey('user.id', ondelete="CASCADE"), nullable=False, index=True)
    target_type = db.Column(db.String(20), nullable=False, index=True)
    target_id = db.Column(db.Integer, nullable=False, index=True)
    reason = db.Column(db.String(255))
    created_at = db.Column(db.DateTime, default=datetime.utcnow, index=True)

    reporter = db.relationship('User', backref='reports_made')


class Block(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    blocker_id = db.Column(db.Integer, db.ForeignKey('user.id', ondelete="CASCADE"), nullable=False, index=True)
    blocked_id = db.Column(db.Integer, db.ForeignKey('user.id', ondelete="CASCADE"), nullable=False, index=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow, index=True)
    __table_args__ = (db.UniqueConstraint('blocker_id', 'blocked_id', name='uq_block'),)

    blocker = db.relationship('User', foreign_keys=[blocker_id], backref='blocks_made')
    blocked = db.relationship('User', foreign_keys=[blocked_id], backref='blocks_received')


class StoryView(db.Model):
    __tablename__ = 'story_view'

    id = db.Column(db.Integer, primary_key=True)
    story_id = db.Column(db.Integer, db.ForeignKey('story.id', ondelete="CASCADE"), nullable=False, index=True)
    viewer_id = db.Column(db.Integer, db.ForeignKey('user.id', ondelete="CASCADE"), nullable=False, index=True)
    viewed_at = db.Column(db.DateTime, default=datetime.utcnow, index=True)

    story = db.relationship('Story', backref='views')
    viewer = db.relationship('User')

    __table_args__ = (
        db.UniqueConstraint('story_id', 'viewer_id', name='uq_story_view_once'),
    )

    def __repr__(self) -> str:
        return f"<StoryView story={self.story_id} viewer={self.viewer_id}>"


class Notification(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id', ondelete="CASCADE"), index=True, nullable=False)
    actor_id = db.Column(db.Integer, db.ForeignKey('user.id', ondelete="CASCADE"), nullable=False, index=True)
    type = db.Column(db.String(30), nullable=False, index=True)
    # Use a factory for JSON default to avoid shared mutable default
    payload = db.Column(JSON, default=dict)
    created_at = db.Column(db.DateTime, default=datetime.utcnow, index=True)
    read = db.Column(db.Boolean, default=False, index=True)

    user = db.relationship('User', foreign_keys=[user_id], backref='notifications')
    actor = db.relationship('User', foreign_keys=[actor_id])


class StoryReply(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    story_id = db.Column(db.Integer, db.ForeignKey('story.id', ondelete="CASCADE"), nullable=False, index=True)
    sender_id = db.Column(db.Integer, db.ForeignKey('user.id', ondelete="CASCADE"), nullable=False, index=True)
    content = db.Column(db.Text, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow, index=True)

    story = db.relationship('Story', backref=db.backref('replies', lazy=True, cascade="all, delete-orphan"))
    sender = db.relationship('User')

    def __repr__(self):
        return f"<StoryReply story={self.story_id} from={self.sender_id}>"


class University(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(160), unique=True, nullable=False, index=True)
    city = db.Column(db.String(120))
    country = db.Column(db.String(120))
    website = db.Column(db.String(255))
    created_at = db.Column(db.DateTime, default=datetime.utcnow, index=True)


class Club(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    university_id = db.Column(db.Integer, db.ForeignKey('university.id', ondelete="CASCADE"), nullable=False, index=True)
    name = db.Column(db.String(160), nullable=False, index=True)
    description = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow, index=True)
    university = db.relationship('University', backref='clubs')


class ClubMember(db.Model):
    __tablename__ = 'club_member'
    id = db.Column(db.Integer, primary_key=True)
    club_id = db.Column(db.Integer, db.ForeignKey('club.id', ondelete="CASCADE"), nullable=False, index=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id', ondelete="CASCADE"), nullable=False, index=True)
    role = db.Column(db.String(32), default="member")
    joined_at = db.Column(db.DateTime, default=datetime.utcnow, index=True)
    club = db.relationship('Club', backref='members')
    user = db.relationship('User', backref='club_memberships')

    __table_args__ = (db.UniqueConstraint('club_id', 'user_id', name='uq_club_member_once'),)


class Event(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(160), nullable=False, index=True)
    description = db.Column(db.Text)
    starts_at = db.Column(db.DateTime, nullable=False, index=True)
    ends_at = db.Column(db.DateTime)
    location = db.Column(db.String(255))
    host_club_id = db.Column(db.Integer, db.ForeignKey('club.id', ondelete="SET NULL"))
    created_by = db.Column(db.Integer, db.ForeignKey('user.id', ondelete="SET NULL"))


class TutoringSkill(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("user.id", ondelete="CASCADE"), nullable=False, index=True)
    skill = db.Column(db.String(100), nullable=False, index=True)


class StudyGroup(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(120), nullable=False, index=True)
    course = db.Column(db.String(120), nullable=False, index=True)
    creator_id = db.Column(db.Integer, db.ForeignKey("user.id", ondelete="CASCADE"), nullable=False, index=True)


class CampusEvent(db.Model):
    __tablename__ = "campus_event"
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(150), nullable=False, index=True)
    date = db.Column(db.String(50), nullable=False, index=True)
    creator_id = db.Column(db.Integer, db.ForeignKey("user.id", ondelete="CASCADE"), nullable=False, index=True)


class EventAttendance(db.Model):
    __tablename__ = "event_attendance"
    id = db.Column(db.Integer, primary_key=True)
    event_id = db.Column(db.Integer, db.ForeignKey("campus_event.id", ondelete="CASCADE"), nullable=False, index=True)
    user_id = db.Column(db.Integer, db.ForeignKey("user.id", ondelete="CASCADE"), nullable=False, index=True)


class ItemCategory(db.Model):
    __tablename__ = "item_categories"
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(60), unique=True, nullable=False, index=True)

    def __repr__(self):
        return f"<ItemCategory {self.name}>"


class MarketplaceItem(db.Model):
    __tablename__ = "marketplace_items"
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(120), nullable=False, index=True)
    description = db.Column(db.Text, nullable=True)
    price = db.Column(db.Float, nullable=False, index=True)
    currency = db.Column(db.String(8), default="USD")
    created_at = db.Column(db.DateTime, default=datetime.utcnow, index=True)

    seller_id = db.Column(db.Integer, db.ForeignKey("user.id", ondelete="CASCADE"), nullable=False, index=True)
    category_id = db.Column(db.Integer, db.ForeignKey("item_categories.id", ondelete="SET NULL"), nullable=True, index=True)
    is_sold = db.Column(db.Boolean, default=False, index=True)

    seller = db.relationship("User", backref=db.backref("marketplace_items", lazy="dynamic"))
    category = db.relationship("ItemCategory", backref=db.backref("items", lazy="dynamic"))


class ItemImage(db.Model):
    __tablename__ = "item_images"
    id = db.Column(db.Integer, primary_key=True)
    filename = db.Column(db.String(255), nullable=False)
    item_id = db.Column(db.Integer, db.ForeignKey("marketplace_items.id", ondelete="CASCADE"), nullable=False, index=True)

    item = db.relationship(
        "MarketplaceItem",
        backref=db.backref("images", lazy="dynamic", cascade="all, delete-orphan")
    )
