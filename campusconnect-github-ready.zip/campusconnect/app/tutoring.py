# app/tutoring.py
from flask import Blueprint, render_template, request, redirect, url_for, flash
from flask_login import login_required, current_user
from . import db
from .models import TutoringSkill, StudyGroup

tutoring = Blueprint("tutoring", __name__, url_prefix="/tutoring")

# Show skills & groups
@tutoring.route("/", methods=["GET", "POST"])
@login_required
def dashboard():
    if request.method == "POST":
        skill = request.form.get("skill")
        if skill:
            new_skill = TutoringSkill(user_id=current_user.id, skill=skill)
            db.session.add(new_skill)
            db.session.commit()
            flash("Skill added!", "success")
            return redirect(url_for("tutoring.dashboard"))

    skills = TutoringSkill.query.filter_by(user_id=current_user.id).all()
    groups = StudyGroup.query.all()
    return render_template("tutoring.html", skills=skills, groups=groups)


# Create a study group
@tutoring.route("/group", methods=["POST"])
@login_required
def create_group():
    name = request.form.get("name")
    course = request.form.get("course")
    if not name or not course:
        flash("Both name and course required", "warning")
        return redirect(url_for("tutoring.dashboard"))

    group = StudyGroup(name=name, course=course, creator_id=current_user.id)
    db.session.add(group)
    db.session.commit()
    flash("Study group created!", "success")
    return redirect(url_for("tutoring.dashboard"))
